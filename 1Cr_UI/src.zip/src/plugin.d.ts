
declare module "react-router-dom";
declare module "rodal";
declare module "react-timer-wrapper";
declare module "react-timecode";
declare module "validator";
declare module "wizard";
declare module "react-timer-wrapper";
declare module "react-simple-maps";
declare module "react-datepicker";
declare module "@simonwep/pickr";
declare module "@tanstack/react-table";
declare module "makeData"