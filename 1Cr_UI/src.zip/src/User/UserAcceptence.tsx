import React, { useState} from "react";
import { Link, useNavigate,useLocation } from "react-router-dom";
import { toast } from 'react-toastify';
import { Alert, Form, InputGroup } from 'react-bootstrap';
import { Imagesdata } from "../commondata/commonimages";
import axios from 'axios';
const UserAcceptance = () => {
    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);    
  const [err] = useState("");
  const [Loader] = useState(false);
  const [passwordshow, setpasswordshow] = useState(false);
  const [ConfirmPasswordShow, SetConfirmPasswordShow] = useState(false);
  const [ConfirmPassword, SetConfirmPassword] = useState('');
  const [data, setData] = React.useState({
    UserId:searchParams.get('UserId'),
    FirstName: "",
    LastName: "",
    EmailId: searchParams.get('EmailId'),
    MobileNumber: "",
    Password: "",
    IsActive:1,
  });
  const { FirstName, LastName, MobileNumber, Password } = data;

  const navigate = useNavigate();
  const RouteChange = () => {
    const path = `${import.meta.env.BASE_URL}`;
    navigate(path);
  };

  const changeHandler = (e: any) => {
    setData({ ...data, [e.target.name]: e.target.value });
  };

  const confirmPasswordChangeHandler = (e: any) => {
    SetConfirmPassword(e.target.value);
  }

  const handleSubmit = (e: any) => {
    e.preventDefault();

    axios.put(`${process.env.URL}/user/update`,data).then((res) => {

      if (res.status == 200) {
        console.log(res);

        toast.success('Registered Successfully!', {
          position: "top-center",
          autoClose: 1000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "colored",
        })
        console.log(res.data.data[0]);
        RouteChange();
      }
    }).catch((err) => {
      console.error(err);
      toast.error('Failed to register. Please try again later', {
        position: "top-center",
        autoClose: 1000,
        hideProgressBar: false, 
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "colored",
      })
    });
  }


  return (
    <>
      <div className='login-img'>
        <div className="page">
          <div className="col-login mx-auto mt-7">
            <div className="text-center">
              <img src={Imagesdata('')} className="header-brand-img m-0" alt="" />
            </div>
          </div>
          <div className="container-login100">
            <div className="wrap-login100 p-6">
              <form className="login100-form validate-form">
                <span className="login100-form-title">
                  Registration
                </span>
                {err && <Alert variant="danger">{err}</Alert>}


                <div className="d-flex gap-2">
                  <div className="wrap-input100 validate-input input-group">
                    <Link to="#" className="input-group-text bg-white text-muted">
                      <i className="zmdi zmdi-email" aria-hidden="true"></i>
                    </Link>
                    <Form.Control
                      className="input100 border-start-0 ms-0 form-control flex-grow-1"
                      type="text"
                      name="FirstName"
                      placeholder="First Name"
                      value={FirstName}
                      onChange={changeHandler}
                    />
                  </div>
                  <div className="wrap-input100 validate-input input-group">
                    <Link to="#" className="input-group-text bg-white text-muted">
                      <i className="zmdi zmdi-email" aria-hidden="true"></i>
                    </Link>
                    <Form.Control
                      className="input100 border-start-0 ms-0 form-control flex-grow-1"
                      type="text"
                      name="LastName"
                      placeholder="Last Name"
                      value={LastName}
                      onChange={changeHandler}
                    />
                  </div>

                </div>

                <div className="wrap-input100 validate-input input-group">
                  <Link to="#" className="input-group-text bg-white text-muted">
                    <i className="zmdi zmdi-email" aria-hidden="true"></i>
                  </Link>
                  <Form.Control
                    className="input100 border-start-0 ms-0 form-control"
                    type="email"
                    name="EmailId"
                    placeholder="Email Id"
                    value={data.EmailId || ''}
                    disabled />
                </div>

                <div className="wrap-input100 validate-input input-group">
                  <Link to="#" className="input-group-text bg-white text-muted">
                    <i className="zmdi zmdi-email" aria-hidden="true"></i>
                  </Link>
                  <Form.Control
                    className="input100 border-start-0 ms-0 form-control"
                    type="tel"
                    name="MobileNumber"
                    placeholder="Mobile Number"
                    value={MobileNumber}
                    onChange={changeHandler} />
                </div>

                <InputGroup className="wrap-input100 validate-input" id="Password-toggle">
                  <InputGroup.Text id="basic-addon2" className="bg-white p-0" onClick={() => setpasswordshow(!passwordshow)}>
                    <Link to='#' className='bg-white text-muted p-3'><i className={`zmdi ${passwordshow ? 'zmdi-eye' : 'zmdi-eye-off'} text-muted`}></i></Link>
                  </InputGroup.Text>
                  <Form.Control
                    className="input100 border-start-0 ms-0"
                    type={(passwordshow) ? 'text' : "Password"}
                    name="Password"
                    placeholder="Password"
                    value={Password}
                    onChange={changeHandler} required />{" "}
                </InputGroup>
                <InputGroup className="wrap-input100 validate-input" id="Password-toggle">
                  <InputGroup.Text id="basic-addon2" className="bg-white p-0" onClick={() => SetConfirmPasswordShow(!ConfirmPasswordShow)}>
                    <Link to='#' className='bg-white text-muted p-3'><i className={`zmdi ${passwordshow ? 'zmdi-eye' : 'zmdi-eye-off'} text-muted`}></i></Link>
                  </InputGroup.Text>

                  <Form.Control
                    className="input100 border-start-0 ms-0"
                    type={(ConfirmPasswordShow) ? 'text' : "password"}
                    name="cnfpassword"
                    placeholder="Confirm Password"
                    value={ConfirmPassword}
                    onChange={confirmPasswordChangeHandler} required />{" "}
                </InputGroup>
                <label className="custom-control custom-checkbox mt-4">
                  <input type="checkbox" className="custom-control-input" />
                  <span className="custom-control-label">I accept all the<Link to={`${import.meta.env.BASE_URL}pages/extension/term/`}> Terms & Conditions </Link> and <Link to={`${import.meta.env.BASE_URL}`}> Privacy Policy</Link></span>
                </label>
                <div className="container-login100-form-btn">
                  <Link to='#' onClick={handleSubmit} className="login100-form-btn btn-primary"> Register

                    {Loader ? <span role="status" aria-hidden="true" className="spinner-border spinner-border-sm ms-2"></span> : ""}
                  </Link>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
// SignUp.propTypes = {};

// SignUp.defaultProps = {};

export default UserAcceptance;
