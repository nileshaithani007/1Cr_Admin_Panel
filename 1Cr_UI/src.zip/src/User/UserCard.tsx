import  { useState } from "react";
import axios from "axios";
import avatar from "../assets/images/brand/Avatar.png";
import {
  Button,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader,
  Form,
  Container
} from "react-bootstrap";
import { toast } from "react-toastify";
import { MultiSelect } from "react-multi-select-component";

const UserCard = (props: any) => {
  // const [reload, setReload] = useState(0);
  const { ele, role } = props;
  const [Role,setRole] = useState([]);
  const [show1, setShow1] = useState(false);
  const xtralargemodal1Close = () => setShow1(false);
  const xtralargemodal1Show = () => {
    console.log("Role",role);
    setRole(role);
    setShow1(true)};

  const [selectedRole, SetselectedRole] = useState([]);

  const [formData] = useState({
    action: "Update",
    ProjectId: ele.ProjectId,
    ProjectName: ele.ProjectName,
    OrgId: 1,
    CreatedBy: null,
    ModifiedBy: 1,
    IsActive: ele.IsActive === 1,
  });

  // const handleChange = (e: any) => {
  //   const { name, value } = e.target;
  //   setFormData({
  //     ...formData,
  //     [name]: value,
  //   });
  // };

  // const handleToggleChange = () => {
  //   setFormData((prevState) => ({
  //     ...prevState,
  //     IsActive: !prevState.IsActive,
  //   }));
  // };

  const handleRoleSelection = (selectedItems: any) => {
    const selection = selectedItems.map((item: any) => ({
      ...item,
    }));
    SetselectedRole(selection);
  };

  const handleSubmit = (e: any) => {
    e.preventDefault();
    axios
      .post(`${process.env.URL}/Project/action`, formData)
      .then((res) => {
        console.log(res);
        
        xtralargemodal1Close();
        // setFormData({
        //   ProjectName: "",
        //   IsActive: false,
        // });
        toast.success("Project updated successfully", {
          position: "top-center",
          autoClose: 1000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      })
      .catch((error) => {
        console.log(error);
        
        toast.error("Failed to update project", {
          position: "top-center",
          autoClose: 1000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      });
  };

  return (
    <>
      <div className="card px-3 py-2 mb-3">
        <div className="d-flex align-items-start">
          <div className="d-flex w-100 align-items-start">
            <div className="w-12 rounded m-1 me-3">
              <img
                src={avatar}
                className="custom_card_image rounded-circle"
                alt="Avatar"
                width={100}
                height={100}
              />
            </div>
            <div className="w-100">
              <div className="d-flex w-100 justify-content-between align-items-center">
                <h4 className="custom_card_title fw-bold mx-1 my-0">
                  Name: {(ele.FirstName && ele.LastName) ? ele.FirstName + ele.LastName : 'Not Available'}
                </h4>
                <div className="d-flex gap-3">
                  <button
                    onClick={xtralargemodal1Show}
                    className="btn btn-sm btn-primary px-3 py-1"
                  >
                    Assign Role
                  </button>
                  <button
                    onClick={xtralargemodal1Show}
                    className="btn btn-sm btn-primary px-3 py-1"
                  >
                    Edit
                  </button>
                </div>
              </div>
              <div className="mt-2">
                <span className="custom_card_sub_title fw-bold mx-1">
                  Email:&nbsp;
                </span>
                <span className="custom_card_sub_title">
                  {ele.EmailId}
                </span>
              </div>
              <div className="mt-3 d-flex align-items-center">
                <div className="badge bg-success me-2">
                  {ele.IsActive ? "Active" : "Inactive"}
                </div>
                {ele.IsActive ? "🟢" : "🔴"}
              </div>
            </div>
          </div>
        </div>
      </div>

      <Modal size="lg" show={show1} onHide={xtralargemodal1Close}>
        <ModalHeader closeButton>
          <Modal.Title as="h3">Assign Role</Modal.Title>
        </ModalHeader>
        <ModalBody>
          <Container>
            <Form onSubmit={handleSubmit}>
              <Form.Group controlId="project_edit">
                <Form.Label>Select Role</Form.Label>
                  <MultiSelect
                    value={selectedRole}
                    onChange={handleRoleSelection}
                    className="w-100 "
                    labelledBy="Select Role"
                    options={Role}
                  />
              </Form.Group>
              <ModalFooter>
                <Button variant="secondary" onClick={xtralargemodal1Close}>
                  Close
                </Button>
                <Button variant="primary" type="submit">
                  Update
                </Button>
              </ModalFooter>
            </Form>
          </Container>
        </ModalBody>
      </Modal>
    </>
  );
};

export default UserCard;
