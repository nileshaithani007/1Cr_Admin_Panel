import axios from "axios";
import {
    Button,
    Modal,
    ModalBody,
    ModalFooter,
    ModalHeader,
    ModalTitle,
    Form,
    Container,
} from "react-bootstrap";
import { useEffect, useState } from "react";
import { toast } from "react-toastify";
import UserCard from "./UserCard";
import { MultiSelect } from "react-multi-select-component";
// import UserCard from "./UserCard";

function UserView() {
    const [Role, SetRole] = useState([]);
    const [selectedRole, SetselectedRole] = useState([]);

   

    const [roleData] = useState({
        RoleId: null,
        RoleName: null,
        CreatedBy: null,
        ModifiedBy: null,
        IsActive: true,
        action: "Get",
    });


    const [formData, setFormData] = useState({
        EmailId: null,
        OrgId:sessionStorage.getItem('OrgId'),
        CreatedBy: 1,
        Roles:[]
    });


    const handleChange = (e: any) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    const handleRoleSelection = (selectedItems: any) => {
        console.log(selectedItems);
        
        const selection = selectedItems.map((item: any) => ({
          ...item,
        }));
        
        SetselectedRole(selection);

        setFormData(prevFormData => ({
            ...prevFormData,
            Roles: selectedItems.map((item:any) => item.value),
        }));


      };

    const handleSubmit = (e: any) => {
        e.preventDefault();
        console.log(formData);

        axios
            .post(`${process.env.URL}/user/create`, formData)
            .then((res) => {
                console.log("Response:", res);
                setReload(reload + 1);
                xtralargemodal1Close();
                setFormData({
                    ...formData,
                });
                toast.success("User added successfully", {
                    position: "top-center",
                    autoClose: 1000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                    theme: "light",
                });
            })
            .catch((error) => {
                console.error("There was an error adding the User:", error);
                toast.error("Failed to add User", {
                    position: "top-center",
                    autoClose: 1000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                    theme: "light",
                });
            });
    };

    const [UserData, SetUserData] = useState([]);
    const [reload, setReload] = useState(0);
    const [loader, setLoader] = useState(false);

    useEffect(() => {
        setLoader(true);
        axios.post(`${process.env.URL}/user/get`, formData.OrgId).then((res) => {
            setLoader(false);
            console.log(res.data.data);
            SetUserData(res.data.data);
        });
    }, [reload]);

    useEffect(() => {
        setLoader(true);
        axios.post(`${process.env.URL}/Role/action`, roleData).then((res) => {
            setLoader(false);
            console.log(res.data.data);
            SetRole(res.data.data);
        });
    }, [reload]);

    // const refresh = () => {
    //     setReload(reload + 1);
    // };

    const [show1, setShow1] = useState(false);
    const xtralargemodal1Close = () => setShow1(false);
    const xtralargemodal1Show = () => setShow1(true);

    return (
        <>
            <div className="page-header mb-0 mt-1">
                <div className="page-title w-50 d-flex align-items-center">
                    <h3 className="custom_page_title fw-bold mt-2">User(s)</h3>
                </div>

                <div>
                    <button className="btn btn-primary" onClick={xtralargemodal1Show}>
                        Create User
                        {/* <i className="fe fe-plus"></i> */}
                    </button>
                </div>
            </div>

            <Modal size="lg" show={show1} onHide={xtralargemodal1Close}>
                <ModalHeader className="align-items-center">
                    <ModalTitle as="h3">Create User</ModalTitle>
                    <span className="d-flex ms-auto" onClick={xtralargemodal1Close}>
                        <i className="fe fe-x ms-auto fe-xl"></i>
                    </span>
                </ModalHeader>
                <ModalBody>
                    <Container className="card px-3 py-2">
                        <Form onSubmit={handleSubmit}>
                            <Form.Group controlId="User">
                                {/* <Form.Label>First Name</Form.Label>
                                <Form.Control
                                    type="text"
                                    placeholder="Enter First Name"
                                    name="FirstName"
                                    //   value={formData.FirstName }
                                    onChange={handleChange}
                                    required
                                />
                                <Form.Label>Last Name</Form.Label> */}
                                {/* <Form.Control
                                    type="text"
                                    placeholder="Enter Last Name"
                                    name="LastName"
                                    //   value={formData.FirstName }
                                    onChange={handleChange}
                                    required
                                /> */}
                                <Form.Label>Email Id</Form.Label>
                                <Form.Control
                                    type="text"
                                    placeholder="Enter Email Id"
                                    name="EmailId"
                                    //   value={formData.FirstName }
                                    onChange={handleChange}
                                    required
                                />
                                {/* <Form.Label>Mobile Number</Form.Label> */}
                                {/* <Form.Control
                                    type="text"
                                    placeholder="Enter Mobile Number"
                                    name="MobileNumber"
                                    //   value={formData.FirstName }
                                    onChange={handleChange}
                                    required
                                /> */}
                                <Form.Label>Select Role</Form.Label>
                                <MultiSelect
                                    value={selectedRole}
                                    onChange={handleRoleSelection}
                                    className="w-100 "
                                    labelledBy="Select Role"
                                    options={Role}
                                />
                                {/* <Form.Control
                  as="select"
                  name="RoleId"
                //   value={formData.ProjectId}
                  onChange={handleChange}
                  required
                >
                  <option value="Select Items" disabled>
                    Select Role
                  </option>


                  {Role.map((role:any) => (
                    <option value={role.RoleId}>
                      {role.RoleName}
                    </option>
                  ))}
                </Form.Control> */}
                            </Form.Group>
                            <ModalFooter>
                                <Button variant="primary" type="submit">
                                    Save & Close
                                </Button>
                            </ModalFooter>
                        </Form>
                    </Container>
                </ModalBody>
            </Modal>

            {loader ? (
                <p>Loading Users...</p>
            ) : (
                UserData.map((ele, ind) => <UserCard key={ind} ele={ele} role={Role}/>)
            )}
        </>
    );
}

export default UserView;
