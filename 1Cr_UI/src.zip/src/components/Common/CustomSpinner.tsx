

const CustomSpinner = () => {
  return (
    <div className='h-85 d-flex flex-column align-items-center justify-items-center'>
      <div className='spinner'></div>
    </div>
  )
}
 
export default CustomSpinner