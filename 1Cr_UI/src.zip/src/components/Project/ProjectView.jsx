import axios from "axios";
import {
  Button,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader,
  ModalTitle,
  Form,
  Container,
} from "react-bootstrap";
import { useEffect, useState } from "react";
import { toast } from "react-toastify";
import ProjectCard from "./ProjectCard";

function ProjectView() {
  const [formData, setFormData] = useState({
    action: "",
    ProjectId: null,
    ProjectName: null,
    OrgId: 1,
    CreatedBy: null,
    ModifiedBy: null,
    IsActive: null,
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    formData.action = "Create";
    formData.OrgId = 1;
    formData.CreatedBy = 1;
    console.log(formData);

    axios
      .post(`${process.env.URL}/Project/action`, formData)
      .then((res) => {
        console.log("Response:", res);
        setReload(reload + 1);
        xtralargemodal1Close();
        setFormData({
          ...formData,
          ProjectName: null,
        });
        toast.success("Project added successfully", {
          position: "top-center",
          autoClose: 1000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      })
      .catch((error) => {
        console.error("There was an error adding the project:", error);
        toast.error("Failed to add project", {
          position: "top-center",
          autoClose: 1000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      });
  };

  const [ProjectOptions, setProjectOptions] = useState([]);
  const [reload, setReload] = useState(0);
  const [loader, setLoader] = useState(false);

  useEffect(() => {
    setLoader(true);
    formData.action = "Get";
    axios.post(`${process.env.URL}/Project/action`, formData).then((res) => {
      setLoader(false);
      console.log(res.data.data[0]);
      setProjectOptions(res.data.data[0]);
    });
  }, [reload]);

  const refresh = () => {
    setReload(reload + 1);
  };

  const [show1, setShow1] = useState(false);
  const xtralargemodal1Close = () => setShow1(false);
  const xtralargemodal1Show = () => setShow1(true);

  return (
    <>
      <div className="page-header mb-0 mt-1">
        <div className="page-title w-50 d-flex align-items-center">
          <h3 className="custom_page_title fw-bold mt-2">Project(s)</h3>
        </div>

        <div>
          <button className="btn btn-primary" onClick={xtralargemodal1Show}>
            Create Project
            {/* <i className="fe fe-plus"></i> */}
          </button>
        </div>
      </div>

      <Modal size="lg" show={show1} onHide={xtralargemodal1Close}>
        <ModalHeader className="align-items-center">
          <ModalTitle as="h3">Project Details</ModalTitle>
          <span className="d-flex ms-auto" onClick={xtralargemodal1Close}>
            <i className="fe fe-x ms-auto fe-xl"></i>
          </span>
        </ModalHeader>
        <ModalBody>
          <Container className="card px-3 py-2">
            <Form onSubmit={handleSubmit}>
              <Form.Group controlId="project">
                <Form.Label>Project</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter Project"
                  name="ProjectName"
                  value={formData.ProjectName}
                  onChange={handleChange}
                  required
                />
              </Form.Group>
              <ModalFooter>
                <Button variant="primary" type="submit">
                  Save & Close
                </Button>
              </ModalFooter>
            </Form>
          </Container>
        </ModalBody>
      </Modal>

      {loader ? (
        <p>Loading projects...</p>
      ) : (
        ProjectOptions.map((ele, ind) => <ProjectCard key={ind} ele={ele} />)
      )}
    </>
  );
}

export default ProjectView;
