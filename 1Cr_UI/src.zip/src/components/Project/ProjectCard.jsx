import React, { useState } from "react";
import axios from "axios";
import avatar from "../../assets/images/brand/Avatar.png";
import {
  Button,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader,
  Form,
  Container,
  Row,
  Col,
} from "react-bootstrap";
import { toast } from "react-toastify";

const ProjectCard = (props) => {
  const [reload, setReload] = useState(0);
  const { ele } = props;
  console.log(ele);
  const [show1, setShow1] = useState(false);
  const xtralargemodal1Close = () => setShow1(false);
  const xtralargemodal1Show = () => setShow1(true);

  const [formData, setFormData] = useState({
    action: "Update",
    ProjectId: ele.ProjectId,
    ProjectName: ele.ProjectName,
    OrgId: 1,
    CreatedBy: null,
    ModifiedBy: 1,
    IsActive: ele.IsActive,
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleToggleChange = () => {
    setFormData((prevData) => ({
      ...prevData,
      IsActive: !prevData.IsActive,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("FormData-----", formData);
    axios
      .post(`${process.env.URL}/Project/action`, formData)
      .then((res) => {
        xtralargemodal1Close();
        setFormData({
          ProjectName: "",
          IsActive: false,
        });
        window.location.reload();
        toast.success("Project updated successfully", {
          position: "top-center",
          autoClose: 1000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      })
      .catch((error) => {
        toast.error("Failed to update project", {
          position: "top-center",
          autoClose: 1000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      });
  };

  return (
    <>
      <div className="card px-3 py-2 mb-3">
        <div className="d-flex align-items-start">
          <div className="d-flex w-100 align-items-start">
            <div className="w-12 rounded m-1 me-3">
              <img
                src={avatar}
                className="custom_card_image rounded-circle"
                alt="Avatar"
                width={100}
                height={100}
              />
            </div>
            <div className="w-100">
              <div className="d-flex w-100 justify-content-between align-items-center">
                <h4 className="custom_card_title fw-bold mx-1 my-0">
                  {ele.ProjectName}
                </h4>
                <button
                  onClick={xtralargemodal1Show}
                  className="btn btn-sm btn-primary px-3 py-1"
                >
                  Edit
                </button>
              </div>
              <div className="mt-2">
                <span className="custom_card_sub_title fw-bold mx-1">
                  Description:&nbsp;
                </span>
                <span className="custom_card_sub_title">
                  Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos,
                  tempore laboriosam. Tempora iusto explicabo minima, natus
                  dicta expedita voluptatem quaerat id voluptates modi officiis
                  nobis dolore, doloremque ipsa, voluptate velit? Explicabo nemo
                  facilis hic? Modi sequi excepturi iure porro voluptatum at
                  odit beatae! Possimus nihil aliquam iusto, accusamus
                  doloremque numquam quod eius quasi autem vero illum soluta
                  quam impedit necessitatibus? Optio nisi ipsum, omnis magnam
                  officia.
                </span>
              </div>
              <div className="mt-3 d-flex align-items-center">
                <div
                  className={`badge ${
                    ele.IsActive ? "bg-success" : "bg-danger"
                  } me-2`}
                >
                  {ele.IsActive ? "Active" : "Inactive"}
                </div>
                {ele.IsActive ? "🟢" : "🔴"}
              </div>
            </div>
          </div>
        </div>
      </div>

      <Modal size="lg" show={show1} onHide={xtralargemodal1Close}>
        <ModalHeader closeButton>
          <Modal.Title as="h3">Project Details</Modal.Title>
        </ModalHeader>
        <ModalBody>
          <Container>
            <Form onSubmit={handleSubmit}>
              <Form.Group controlId="project Nameroject_edit">
                <Form.Label>Project Name</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter Project Name"
                  name="ProjectName"
                  value={formData.ProjectName}
                  onChange={handleChange}
                  required
                />
              </Form.Group>
              <Form.Group controlId="status_toggle" className="mt-3">
                <Form.Label>Status</Form.Label>
                <Form.Check
                  type="switch"
                  name="toggle"
                  //   label={formData.IsActive ? "Active" : "Inactive"}
                  checked={formData.IsActive}
                  onChange={handleToggleChange}
                />
              </Form.Group>
              <ModalFooter>
                <Button variant="secondary" onClick={xtralargemodal1Close}>
                  Close
                </Button>
                <Button variant="primary" type="submit">
                  Update
                </Button>
              </ModalFooter>
            </Form>
          </Container>
        </ModalBody>
      </Modal>
    </>
  );
};

export default ProjectCard;
