import React, { useState } from "react";
import { Button, Card, Col, Form, Row } from "react-bootstrap";
import PageHeader from "../../layouts/layoutcomponents/pageheader";
import Select from "react-select";
import { toast } from "react-toastify";

const TeamMemberMapping: React.FC = () => { // Define the component as a React Functional Component

  const DepartmentOption = [
    { value: "Choose one", label: "Choose one", isDisabled: true },
    { value: "1", label: "Leadership" },
    { value: "2", label: "Developer" },
    { value: "3", label: "BA" },
    { value: "4", label: "Code Review" },
    { value: "5", label: "Support" },
  ];

  const [memberOptions] = useState([
    { value: "Choose one", label: "Choose one", isDisabled: true },
    { value: "1", label: "Hari" },
    { value: "2", label: "Zehan" },
    { value: "3", label: "Nikhil" },
    { value: "4", label: "Gautam" },
    { value: "5", label: "Tarun" },
    { value: "6", label: "Deepak" },
    { value: "7", label: "Shipra" },
    { value: "8", label: "Aniket" },
    { value: "9", label: "Kuldeep" },
    { value: "10", label: "Shipra" },
    { value: "11", label: "Aniket" },
    { value: "12", label: "Satender" },
    { value: "13", label: "Praveen" },
  ]);

  const [team, setTeam] = useState<string | null>(""); // Define team as a string or null
  // const [teamId, setTeamId] = useState<string | null>(null); // Define teamId as a string or null
  const [member, setMember] = useState<string | null>(""); // Define member as a string or null
  // const [memberId, setMemberId] = useState<string | null>(null); // Define memberId as a string or null
  const [data, setData] = useState<{ team: string | null; member: string | null }[]>([]);

  const handleMember = () => {
    if (team !== "" && member !== "") {
      const obj = { team, member };
      setData([...data, obj]);
    } else if (team !== "") {
      toast.error('Please Select Team Member', {
        position: "top-center",
        autoClose: 2000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "colored",
      });
    } else if (member !== "") {
      toast.error('Please Select Team', {
        position: "top-center",
        autoClose: 2000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "colored",
      });
    } else {
      toast.error('Enter All Details', {
        position: "top-center",
        autoClose: 2000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "colored",
      });
    }
    // console.log(teamId,memberId)
  };

  return (
    <div className="container">
      <PageHeader
        titles="Team Member Master"
        active="Team Member Master"
        items={["Home"]}
      />

      <Card className="p-3 overflow-y-auto overflow-x-hidden">
        <Card.Body>
          <Row>
            <Col sm={6} md={4}>
              <Form.Group className="mb-1 d-flex">
                <Form.Label className="me-1">Teams:</Form.Label>
                <Select
                  placeholder="Select"
                  onChange={(e: any) => {
                    setTeam(e.label);
                    // setTeamId(e.value);
                  }}
                  className="flex-grow-1"
                  options={DepartmentOption}
                />
              </Form.Group>
            </Col>
            <Col sm={6} md={4}>
              <Form.Group className="mb-1 d-flex">
                <Form.Label className="me-1">Members:</Form.Label>
                <Select
                  placeholder="Select"
                  className="flex-grow-1"
                  options={memberOptions}
                  onChange={(e: any) => {
                    setMember(e.label);
                    // setMemberId(e.value);
                  }}
                />
              </Form.Group>
            </Col>
            <Col sm={6} md={4}>
              <Button className="btn btn-primary" onClick={handleMember}>
                ADD Member
              </Button>
            </Col>
          </Row>
        </Card.Body>
      </Card>
      <div>
        <Card>
          <Card.Body>
            <Row className="fw-bold">
              <Col>S.No</Col>
              <Col>Team</Col>
              <Col>Members</Col>
            </Row>
          </Card.Body>
          <Card.Body >
            {data.length > 0 ? data.map((ele, ind) => {
              return (<>
                <Row key={ind} className="row pt-1 pb-1">
                  <Col>{ind + 1}</Col>
                  <Col>{ele.team}</Col>
                  <Col>{ele.member}</Col>
                </Row>
                  <hr/>
              </>
              );
            }) : ""}
          </Card.Body>
        </Card>
      </div>
    </div>
  );
};

export default TeamMemberMapping;
