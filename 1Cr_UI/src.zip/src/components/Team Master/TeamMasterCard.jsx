import React, { useState } from "react";
import axios from "axios";
import avatar from "../../assets/images/brand/Avatar.png";
import { MultiSelect } from "react-multi-select-component";
import {
  Button,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader,
  Form,
  Container,
  Row,
  Col,
} from "react-bootstrap";
import { toast } from "react-toastify";

const TeamMasterCard = (props) => {
  const [reload, setReload] = useState(0);
  const { ele } = props;
  const [show1, setShow1] = useState(false);
  const xtralargemodal1Close = () => setShow1(false);
  const xtralargemodal1Show = () => setShow1(true);

  const [formData, setFormData] = useState({
    action: "UPDATE",
    TeamId: ele.TeamId,
    TeamName: ele.TeamName,
    CreatedBy: ele.CreatedBy,
    ModifiedBy: sessionStorage.getItem("UserId"),
    IsActive: ele.IsActive,
  });
  // console.log(ele.IsActive);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleToggleChange = () => {
    setFormData((prevState) => ({
      ...prevState,
      // IsActive: !prevState.IsActive,
      IsActive: !prevState.IsActive ? 1 : 0,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios
      .post(`${process.env.URL}/teammaster/action`, formData)
      .then((res) => {
        xtralargemodal1Close();
        setFormData({
          ...formData,
          TeamName: "",
          ModifiedBy: null,
        });
        window.location.reload();
        toast.success("Team Master updated successfully", {
          position: "top-center",
          autoClose: 1000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      })
      .catch((error) => {
        toast.error("Failed to update team master", {
          position: "top-center",
          autoClose: 1000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      });
  };

  return (
    <>
      <div className="card px-3 py-2 mb-3">
        <div className="d-flex align-items-start">
          <div className="d-flex w-100 align-items-start">
            <div className="w-12 rounded m-1 me-3">
              <img
                src={avatar}
                className="custom_card_image rounded-circle"
                alt="Avatar"
                width={100}
                height={100}
              />
            </div>
            <div className="w-100">
              <div className="d-flex w-100 justify-content-between align-items-center">
                <h4 className="custom_card_title fw-bold mx-1 my-0">
                  {ele.TeamName}
                </h4>
                <button
                  onClick={xtralargemodal1Show}
                  className="btn btn-sm btn-primary px-3 py-1"
                >
                  Edit
                </button>
              </div>
              <div className="mt-2">
                <span className="custom_card_sub_title fw-bold mx-1">
                  Description:&nbsp;
                </span>
                <span className="custom_card_sub_title">
                  Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos,
                  tempore laboriosam. Tempora iusto explicabo minima, natus
                  dicta expedita voluptatem quaerat id voluptates modi officiis
                  nobis dolore, doloremque ipsa, voluptate velit? Explicabo nemo
                  facilis hic? Modi sequi excepturi iure porro voluptatum at
                  odit beatae! Possimus nihil aliquam iusto, accusamus
                  doloremque numquam quod eius quasi autem vero illum soluta
                  quam impedit necessitatibus.
                </span>
              </div>
              <div className="mt-3 d-flex align-items-center">
                <div className="badge bg-success me-2">
                  {formData.IsActive ? "Active" : "Inactive"}
                </div>
                {formData.IsActive ? "🟢" : "🔴"}
              </div>
            </div>
          </div>
        </div>
      </div>

      <Modal size="lg" show={show1} onHide={xtralargemodal1Close}>
        <ModalHeader closeButton>
          <Modal.Title as="h3">Team Master Details</Modal.Title>
        </ModalHeader>
        <ModalBody>
          <Container>
            <Form onSubmit={handleSubmit}>
              <Form.Group controlId="project_edit">
                <Form.Label>Team Master Name</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter Team Master Name"
                  name="TeamName"
                  value={formData.TeamName}
                  onChange={handleChange}
                  required
                />
              </Form.Group>
              <Form.Group controlId="status_toggle" className="mt-3">
                <Form.Label>Status</Form.Label>
                <Form.Check
                  type="switch"
                  name="toggle"
                  //   label={formData.IsActive ? "Active" : "Inactive"}
                  checked={formData.IsActive}
                  onChange={handleToggleChange}
                />
              </Form.Group>
              <ModalFooter>
                <Button variant="secondary" onClick={xtralargemodal1Close}>
                  Close
                </Button>
                <Button variant="primary" type="submit">
                  Update
                </Button>
              </ModalFooter>
            </Form>
          </Container>
        </ModalBody>
      </Modal>
    </>
  );
};

export default TeamMasterCard;
