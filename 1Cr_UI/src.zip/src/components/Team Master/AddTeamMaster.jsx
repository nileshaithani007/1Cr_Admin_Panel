import axios from "axios";
import {
  Button,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader,
  ModalTitle,
  Form,
  Container,
} from "react-bootstrap";
import { useEffect, useState } from "react";
import { toast } from "react-toastify";
import TeamMasterCard from "./TeamMasterCard";

function AddTeamMaster() {
  const [formData, setFormData] = useState({
    action: "",
    TeamId: null,
    TeamName: null,
    CreatedBy: sessionStorage.getItem("UserId"),
    ModifiedBy: null,
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    formData.action = "CREATE";
    // console.log(formData);

    axios
      .post(`${process.env.URL}/teammaster/action`, formData)
      .then((res) => {
        console.log(res['data']['objTeamMaster'].length);
        console.log(res);
        setReload(reload + 1);
        xtralargemodal1Close();
        setFormData({
          ...formData,
          TeamName: null,
        });
        if(res['data']['objTeamMaster'].length < 5)
        {
            toast.success("Team Master added successfully", {
            position: "top-center",
            autoClose: 1000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "light",
            });
        }
        else
        {
            toast.error("Team Name Already Exists", {
                position: "top-center",
                autoClose: 1000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "light",
              });
        }
      })
      .catch((error) => {
        console.error("There was an error adding the team master:", error);
        toast.error("Failed to add team master", {
          position: "top-center",
          autoClose: 1000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      });
  };

  const [TeamMasterOptions, setTeamMasterOptions] = useState([]);
  const [reload, setReload] = useState(0);
  const [loader, setLoader] = useState(false);

  useEffect(() => {
    setLoader(true);
    formData.action = "GET";
    // formData.TeamId = 1;
    // // console.log(formData);
    axios.post(`${process.env.URL}/teammaster/action`, formData).then((res) => {
      setLoader(false);
      // console.log(res.data.objTeamMaster[0][0][0]);
      setTeamMasterOptions(res.data.objTeamMaster[0][0]);
    });
  }, [reload]);

  const refresh = () => {
    setReload(reload + 1);
  };

  const [show1, setShow1] = useState(false);
  const xtralargemodal1Close = () => setShow1(false);
  const xtralargemodal1Show = () => setShow1(true);

  return (
    <>
      <div className="page-header mb-0 mt-1">
        <div className="page-title w-50 d-flex align-items-center">
          <h3 className="custom_page_title fw-bold mt-2">Team Master(s)</h3>
        </div>

        <div>
          <button className="btn btn-primary" onClick={xtralargemodal1Show}>
            Create Team Master
            {/* <i className="fe fe-plus"></i> */}
          </button>
        </div>
      </div>

      <Modal size="lg" show={show1} onHide={xtralargemodal1Close}>
        <ModalHeader className="align-items-center">
          <ModalTitle as="h3">Team Master Details</ModalTitle>
          <span className="d-flex ms-auto" onClick={xtralargemodal1Close}>
            <i className="fe fe-x ms-auto fe-xl"></i>
          </span>
        </ModalHeader>
        <ModalBody>
          <Container className="card px-3 py-2">
            <Form onSubmit={handleSubmit}>
              <Form.Group controlId="teammaster">
                <Form.Label>Team Master</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter Team Master"
                  name="TeamName"
                  value={formData.TeamName}
                  onChange={handleChange}
                  required
                />
              </Form.Group>
              <ModalFooter>
                <Button variant="primary" type="submit">
                  Save & Close
                </Button>
              </ModalFooter>
            </Form>
          </Container>
        </ModalBody>
      </Modal>

      {loader ? (
        <p>Loading team master...</p>
      ) : (
        TeamMasterOptions.map((ele, ind) => (
          <TeamMasterCard key={ind} ele={ele} />
        ))
      )}
    </>
  );
}

export default AddTeamMaster;
