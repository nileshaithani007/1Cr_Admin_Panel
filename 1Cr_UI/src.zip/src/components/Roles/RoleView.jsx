import axios from "axios";
import {
  Button,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader,
  ModalTitle,
  Form,
  Container,
} from "react-bootstrap";
import { useEffect, useState } from "react";
import { toast } from "react-toastify";
import RoleCard from "./RoleCard";
 
function RoleView() {
  const [formData, setFormData] = useState({
    action: "",
    RoleId: null,
    RoleName: null,
    CreatedBy: null,
    ModifiedBy: null,
    IsActive: null,
  });
 
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };
 
  const handleSubmit = (e) => {
    e.preventDefault();
    formData.action = "Create";
    // formData.OrgId = 1;
    // formData.RoleId = 1;
    formData.CreatedBy = 1;
    console.log(formData);
 
    axios
      .post(`${process.env.URL}/Role/action`, formData)
      .then((res) => {
        console.log("Response:", res.data);
        setReload(reload + 1);
        xtralargemodal1Close();
        setFormData({
          ...formData,
          RoleName: null,
        });
        toast.success("Role added successfully", {
          position: "top-center",
          autoClose: 1000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      })
      .catch((error) => {
        console.error("There was an error adding the Role:", error);
        toast.error("Failed to add Role", {
          position: "top-center",
          autoClose: 1000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      });
  };
 
  const [RoleOptions, setRoleOptions] = useState([]);
  const [reload, setReload] = useState(0);
  const [loader, setLoader] = useState(false);
 
  useEffect(() => {
    setLoader(true);
    formData.action = "Get";
    axios.post(`${process.env.URL}/Role/action`, formData).then((res) => {
      setLoader(false);
      console.log(res.data.data);
      setRoleOptions(res.data.data);
    });
  }, [reload]);
 
  const refresh = () => {
    setReload(reload + 1);
  };
 
  const [show1, setShow1] = useState(false);
  const xtralargemodal1Close = () => setShow1(false);
  const xtralargemodal1Show = () => setShow1(true);
 
  return (
    <>
      <div className="page-header mb-0 mt-1">
        <div className="page-title w-50 d-flex align-items-center">
          <h3 className="custom_page_title fw-bold mt-2">Role(s)</h3>
        </div>
 
        <div>
          <button className="btn btn-primary" onClick={xtralargemodal1Show}>
            Create Role
            {/* <i className="fe fe-plus"></i> */}
          </button>
        </div>
      </div>
 
      <Modal size="lg" show={show1} onHide={xtralargemodal1Close}>
        <ModalHeader className="align-items-center">
          <ModalTitle as="h3">Role Details</ModalTitle>
          <span className="d-flex ms-auto" onClick={xtralargemodal1Close}>
            <i className="fe fe-x ms-auto fe-xl"></i>
          </span>
        </ModalHeader>
        <ModalBody>
          <Container className="card px-3 py-2">
            <Form onSubmit={handleSubmit}>
              <Form.Group controlId="rolemaster">
                <Form.Label>Role</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter Role"
                  name="RoleName"
                  value={formData.RoleName}
                  onChange={handleChange}
                  required
                />
              </Form.Group>
              <ModalFooter>
                <Button variant="primary" type="submit">
                  Save & Close
                </Button>
              </ModalFooter>
            </Form>
          </Container>
        </ModalBody>
      </Modal>
 
      {loader ? (
        <p>Loading Roles...</p>
      ) : (
        RoleOptions.map((ele, ind) => <RoleCard key={ind} ele={ele} />)
      )}
    </>
  );
}
 
export default RoleView;