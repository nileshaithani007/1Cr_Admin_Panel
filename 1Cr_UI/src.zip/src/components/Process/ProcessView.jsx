import axios from "axios";
import React, { useState, useEffect } from "react";
import { Button, Modal, Form, Container } from "react-bootstrap";
import { toast } from "react-toastify";
import ProcessCard from "./ProcessCard";

function ProcessView() {
  const [formData, setFormData] = useState({
    ProcessId: null,
    ProcessName: "",
    ProcessDescription: "",
    EstTime: "",
    ProcessOwner: "",
    ProjectId: null,
    OrgId: sessionStorage.getItem("OrgId"),
    CreatedBy: sessionStorage.getItem("UserId"),
    ModifiedBy: null,
    IsActive: null,
  });

  const [ProcessOptions, setProcessOptions] = useState([]);
  const [projects, setProjects] = useState([]);
  const [reload, setReload] = useState(0);
  const [loader, setLoader] = useState(false);
  const [showModal, setShowModal] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const submitData = {
      ...formData,
      action: "Create",
    };
    axios
      .post(`${process.env.URL}/Process/action`, submitData)
      .then((res) => {
        console.log("Response:", res);
        setReload(reload + 1);
        setShowModal(false);
        resetForm();
        toast.success("Process added successfully", { position: "top-center" });
      })
      .catch((error) => {
        console.error("Error adding process:", error);
        toast.error("Failed to add process", { position: "top-center" });
      });
  };

  const resetForm = () => {
    setFormData({
      ProcessId: null,
      ProcessName: "",
      ProcessDescription: "",
      EstTime: "",
      ProcessOwner: "",
      ProjectId: null,
      OrgId: 1,
      CreatedBy: 1,
      ModifiedBy: null,
      IsActive: null,
    });
  };

  useEffect(() => {
    setLoader(true);
    axios
      .post(`${process.env.URL}/Process/action`, { action: "Get" })
      .then((res) => {
        setLoader(false);
        // console.log(res.data.objProcess[0][0]);
        setProcessOptions(res?.data?.objProcess[0][0]);
      })
      .catch((error) => {
        setLoader(false);
        console.error("Error fetching processes:", error);
      });
  }, [reload]);

  useEffect(() => {
    const fetchProjects = async () => {
      try {
        const response = await axios.post(`${process.env.URL}/Project/action`, {
          action: "Get",
        });
        setProjects(response.data.data[0]);
      } catch (error) {
        console.error("Error fetching projects:", error);
      }
    };

    fetchProjects();
  }, []);

  return (
    <>
      <div className="page-header mb-0 mt-1">
        <div className="page-title w-50 d-flex align-items-center">
          <h3 className="custom_page_title fw-bold mt-2">Process(s)</h3>
        </div>
        <div>
          <Button
            className="btn btn-primary"
            onClick={() => setShowModal(true)}
          >
            Create Process
          </Button>
        </div>
      </div>

      <Modal size="lg" show={showModal} onHide={() => setShowModal(false)}>
        <Modal.Header className="align-items-center">
          <Modal.Title as="h3">Process Details</Modal.Title>
          <span
            className="d-flex ms-auto"
            onClick={() => setShowModal(false)}
            style={{ cursor: "pointer" }}
          >
            <i className="fe fe-x ms-auto fe-xl"></i>
          </span>
        </Modal.Header>
        <Modal.Body>
          <Container className="card px-3 py-2">
            <Form onSubmit={handleSubmit}>
              <Form.Group controlId="processName">
                <Form.Label>Process Name</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter Process Name"
                  name="ProcessName"
                  value={formData.ProcessName}
                  onChange={handleChange}
                  required
                />
              </Form.Group>
              <Form.Group controlId="processDescription">
                <Form.Label>Process Description</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter Process Description"
                  name="ProcessDescription"
                  value={formData.ProcessDescription}
                  onChange={handleChange}
                  required
                />
              </Form.Group>
              <Form.Group controlId="estTime">
                <Form.Label>Estimated Time</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter Estimated Time"
                  name="EstTime"
                  value={formData.EstTime}
                  onChange={handleChange}
                  required
                />
              </Form.Group>
              <Form.Group controlId="processOwner">
                <Form.Label>Process Owner</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter Process Owner"
                  name="ProcessOwner"
                  value={formData.ProcessOwner}
                  onChange={handleChange}
                  required
                />
              </Form.Group>
              <Form.Group controlId="projectId">
                <Form.Label>Project Name</Form.Label>
                <Form.Control
                  as="select"
                  name="ProjectId"
                  value={formData.ProjectId}
                  onChange={handleChange}
                  required
                >
                  <option value="" enable>
                    Select Project
                  </option>
                  {projects.map((project) => (
                    <option key={project.ProjectId} value={project.ProjectId}>
                      {project.ProjectName}
                    </option>
                  ))}
                </Form.Control>
              </Form.Group>
              <Modal.Footer>
                <Button variant="primary" type="submit">
                  Save & Close
                </Button>
              </Modal.Footer>
            </Form>
          </Container>
        </Modal.Body>
      </Modal>

      {loader ? (
        <p>Loading process...</p>
      ) : (
        ProcessOptions.map((ele, ind) => <ProcessCard key={ind} ele={ele} />)
      )}
    </>
  );
}

export default ProcessView;
