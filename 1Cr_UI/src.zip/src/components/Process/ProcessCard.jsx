import React, { useState, useEffect } from "react";
import axios from "axios";
import avatar from "../../assets/images/brand/Avatar.png";
import {
  Button,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader,
  Form,
  Container,
} from "react-bootstrap";
import { toast } from "react-toastify";

const ProcessCard = ({ ele }) => {
  console.log("ele---", ele);
  const [showModal, setShowModal] = useState(false);
  const [projects, setProjects] = useState([]);

  const initialFormData = {
    ProcessId: ele.ProcessId,
    EstTime: ele.EstTime,
    ProcessName: ele.ProcessName,
    ProcessDescription: ele.ProcessDescription,
    ProcessOwner: ele.ProcessOwner,
    ProjectId: ele.ProjectId,
    OrgId: 1,
    CreatedBy: ele.CreatedBy,
    ModifiedBy: 1,
    IsActive: ele.IsActive,
    action: "Update",
  };      

  const [formData, setFormData] = useState(initialFormData);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleToggleChange = () => {
    setFormData((prevData) => ({
      ...prevData,
      IsActive: !prevData.IsActive,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("FormData-----", formData);
    axios
      .post(`${process.env.URL}/Process/action`, formData)
      .then((res) => {
        setShowModal(false);
        setFormData(initialFormData); // Reset form data after submission
        window.location.reload();
        toast.success("Process updated successfully", {
          position: "top-center",
        });
        
      })
      .catch((error) => {
        toast.error("Failed to update process", { position: "top-center" });
      });
  };

  const closeModal = () => {
    setShowModal(false);
    setFormData(resetFormData); // Reset form data on modal close
  };

  useEffect(() => {
    const fetchProjects = async () => {
      try {
        const response = await axios.post(`${process.env.URL}/Project/action`, {
          action: "Get",
        });
        console.log(response.data.data[0]);
        setProjects(response.data.data[0]);
      } catch (error) {
        console.error("Error fetching projects:", error);
      }
    };

    fetchProjects();
  }, []);

  return (
    <>
      <div className="card px-3 py-2 mb-3">
        <div className="d-flex align-items-start">
          <div className="d-flex w-100 align-items-start">
            <div className="w-12 rounded m-1 me-3">
              <img
                src={avatar}
                className="custom_card_image rounded-circle"
                alt="Avatar"
                width={100}
                height={100}
              />
            </div>
            <div className="w-100">
              <div className="d-flex w-100 justify-content-between align-items-center">
                <h4 className="custom_card_title fw-bold mx-1 my-0">
                  {ele.ProcessName}
                </h4>
                <button
                  onClick={() => setShowModal(true)}
                  className="btn btn-sm btn-primary px-3 py-1"
                >
                  Edit
                </button>
              </div>
              <div className="mt-2">
                <span className="custom_card_sub_title fw-bold mx-1">
                  Description:&nbsp;
                </span>
                <span className="custom_card_sub_title">
                  {ele.ProcessDescription}
                </span>
              </div>
              <div className="mt-3 d-flex align-items-center">
                {ele.IsActive ? "🟢" : "🔴"}
                <div
                  className={`badge ${
                    ele.IsActive ? "bg-success" : "bg-danger"
                  } me-2`}
                >
                  {ele.IsActive ? "Active" : "Inactive"}
                </div>

                <div className="badge bg-info mx-2">
                  Project: {ele.ProjectName}
                </div>

                <div className="badge bg-secondary mx-2">
                  EST Time: {ele.EstTime}
                </div>

                <div className="badge bg-warning mx-2">
                  Owner: {ele.ProcessOwner}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Modal size="lg" show={showModal} onHide={closeModal}>
        <ModalHeader closeButton>
          <Modal.Title as="h3">Edit Process</Modal.Title>
        </ModalHeader>
        <ModalBody>
          <Container>
            <Form onSubmit={handleSubmit}>
              <Form.Group controlId="processName">
                <Form.Label>Process Name</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter Process Name"
                  name="ProcessName"
                  value={formData.ProcessName}
                  onChange={handleChange}
                  required
                />
                <Form.Group controlId="description" className="mt-3">
                  <Form.Label>Description</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Enter Description"
                    name="ProcessDescription"
                    value={formData.ProcessDescription}
                    onChange={handleChange}
                    required
                  />
                </Form.Group>
                <Form.Group controlId="estTime" className="mt-3">
                  <Form.Label>EST Time</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Enter EST Time"
                    name="EstTime"
                    value={formData.EstTime}
                    onChange={handleChange}
                  />
                </Form.Group>
                <Form.Group controlId="processOwner" className="mt-3">
                  <Form.Label>Process Owner</Form.Label>
                  <Form.Control
                    type="text"
                    placeholder="Enter Process Owner"
                    name="ProcessOwner"
                    value={formData.ProcessOwner}
                    onChange={handleChange}
                  />
                </Form.Group>

                <Form.Group controlId="projectId">
                  <Form.Label>Project Name</Form.Label>
                  <Form.Control
                    as="select"
                    name="ProjectId"
                    value={formData.ProjectId}
                    onChange={handleChange}
                    required
                  >
                    <option value="" enable>
                      Select Project
                    </option>
                    {projects.map((project) => (
                      <option key={project.ProjectId} value={project.ProjectId}>
                        {project.ProjectName}
                      </option>
                    ))}
                  </Form.Control>
                </Form.Group>
              </Form.Group>
              <Form.Group controlId="status_toggle" className="mt-3">
                <Form.Label>Status</Form.Label>
                <Form.Check
                  type="switch"
                  id="toggle"
                  // label={formData.IsActive ? "Active" : "Inactive"}
                  checked={formData.IsActive}
                  onChange={handleToggleChange}
                />
              </Form.Group>
              <ModalFooter>
                <Button variant="secondary" onClick={closeModal}>
                  Close
                </Button>
                <Button variant="primary" type="submit">
                  Update
                </Button>
              </ModalFooter>
            </Form>
          </Container>
        </ModalBody>
      </Modal>
    </>
  );
};

export default ProcessCard;
